from PIL import Image
from skimage.io import imread, imshow, show
import scipy.fftpack as fp
from scipy import ndimage, misc, signal
from skimage import data, img_as_float
from skimage.color import rgb2gray
from skimage.transform import rescale
import matplotlib.pylab as pylab
import numpy as np
import numpy.fft
import timeit

def signaltonoise(a, axis=0, ddof=0):
    a = np.asanyarray(a)
    m = a.mean(axis)
    sd = a.std(axis=axis, ddof=ddof)
    return np.where(sd == 0, 0, m/sd)


#%% Simple fft, ifft
im = np.array(Image.open('./images/rhino.jpg').convert('L')) 
snr = signaltonoise(im, axis=None)
print('SNR for the original image = ' + str(snr))

freq = fp.fft2(im)
im1 = fp.ifft2(freq).real
snr = signaltonoise(im1, axis=None)
print('SNR for the image obtained after reconstruction = ' + str(snr))
print(np.allclose(im, im1))
assert(np.allclose(im, im1))

pylab.figure(figsize=(20,10))
pylab.subplot(121), pylab.imshow(im, cmap='gray'), pylab.axis('off')
pylab.title('Original Image', size=20)

pylab.subplot(122), pylab.imshow(im1, cmap='gray'), pylab.axis('off')
pylab.title('Image obtained after reconstruction', size=20)
pylab.show()


#%% fft fourier spectrum : log projection
freq2 = fp.fftshift(freq)
pylab.figure(figsize=(10,10)), pylab.imshow( (20*np.log10( 0.1 + freq2)).astype(int))
pylab.show()


#%% numpy fft
import numpy.fft as fp

im1 = rgb2gray(imread('./images/house.png'))
pylab.figure(figsize=(12,10))

freq1 = fp.fft2(im1)
im1_ = fp.ifft2(freq1).real

pylab.subplot(2,2,1), pylab.imshow(im1, cmap='gray') 
pylab.title('Original Image', size=20)
            
pylab.subplot(2,2,2), pylab.imshow(20*np.log10( 0.01 + np.abs(fp.fftshift(freq1))), cmap='gray')
pylab.title('FFT Spectrum Maginitude', size=20)

pylab.subplot(2,2,3), pylab.imshow(np.angle(fp.fftshift(freq1)),cmap='gray')
pylab.title('FFT Phase', size=20)

pylab.subplot(2,2,4), pylab.imshow(np.clip(im1_,0,255), cmap='gray')
pylab.title('Reconstructed Image', size=20)
pylab.show()


#%% numpy fft2
im2 = rgb2gray(imread('./images/house2.png'))
pylab.figure(figsize=(12,10))

freq2 = fp.fft2(im2)
im2_ = fp.ifft2(freq2).real

pylab.subplot(2,2,1), pylab.imshow(im2, cmap='gray') 
pylab.title('Original Image', size=20)

pylab.subplot(2,2,2), pylab.imshow(20*np.log10( 0.01 + np.abs(fp.fftshift(freq2))), cmap='gray')
pylab.title('FFT Spectrum Maginitude', size=20)

pylab.subplot(2,2,3), pylab.imshow(np.angle(fp.fftshift(freq2)), cmap='gray')
pylab.title('FFT Phase', size=20)

pylab.subplot(2,2,4), pylab.imshow(np.clip(im2_,0,255), cmap='gray')
pylab.title('Reconstructed Image', size=20)
pylab.show()


#%% real, imagery confusion
pylab.figure(figsize=(20,15))
im1_ = fp.ifft2(np.vectorize(complex)(freq1.real, freq2.imag)).real
im2_ = fp.ifft2(np.vectorize(complex)(freq2.real, freq1.imag)).real

pylab.subplot(211), pylab.imshow(np.clip(im1_,0,255), cmap='gray')
pylab.title('Reconstructed Image (Re(F1) + Im(F2))', size=20)

pylab.subplot(212), pylab.imshow(np.clip(im2_,0,255), cmap='gray')
pylab.title('Reconstructed Image (Re(F2) + Im(F1))', size=20)
pylab.show()

 

#%% Complex number processing
a = 2 + 3j
b = complex(3, -4)
print(a.real, b.imag)
c = a + b
print(c)



#%% vectorize
a = np.vectorize(complex)(np.array([1,2,3,4]), np.array([5,6,7,8]) ) 
print(a)

def myfunc(a, b):
    if a > b:
        return a - b
    else:
        return a + b

b = np.vectorize(myfunc)([1, 2, 3, 4], 2)
print(b)

vfunc = np.vectorize(myfunc)
c = vfunc([1, 2, 3, 4], 2)
print(c)

