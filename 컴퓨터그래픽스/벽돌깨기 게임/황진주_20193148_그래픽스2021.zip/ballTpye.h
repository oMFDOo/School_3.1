#pragma once
struct BALLPOINT {
	double x;
	double y;
};