from PIL import Image
from skimage.io import imread, imshow, show
import scipy.fftpack as fp
from scipy import ndimage, misc, signal
from skimage import data, img_as_float
from skimage.color import rgb2gray
from skimage.transform import rescale
import matplotlib.pylab as pylab
import numpy as np
import numpy.fft
import timeit
    


#%% scipy convolution
im = rgb2gray(imread('./images/cameraman.jpg')).astype(float)
blur_box_kernel = np.ones((3,3)) / 9
edge_laplace_kernel = np.array([[0,1,0],[1,-4,1],[0,1,0]])

im_blurred = signal.convolve2d(im, blur_box_kernel)
im_edges = np.clip(signal.convolve2d(im, edge_laplace_kernel), 0, 1)

pylab.figure(figsize=(18,6))
pylab.subplot(1,3,1), pylab.imshow(im,cmap='gray')
pylab.title('Original Image', size=20), pylab.axis('off')

pylab.subplot(1,3,2), pylab.imshow(im_blurred,cmap='gray')
pylab.title('Box Blur', size=20), pylab.axis('off')

pylab.subplot(1,3,3), pylab.imshow(im_edges,cmap='gray')
pylab.title('Laplace Edge Detection', size=20), pylab.axis('off')
pylab.show()



#%% subplot 변형하기
fig, axes = pylab.subplots(ncols=3, sharex=True, sharey=True, figsize=(18,6))
axes[0].imshow(im, cmap=pylab.cm.gray)
axes[0].set_title('Original Image', size=20)

axes[1].imshow(im_blurred, cmap=pylab.cm.gray)
axes[1].set_title('Box Blur', size=20)

axes[2].imshow(im_edges, cmap=pylab.cm.gray)
axes[2].set_title('Laplace Edge Detection', size=20)
for ax in axes:
    ax.axis('off')
pylab.show()



#%% numpy clip
# clip(array, min, max) : min 보다 작으면 min으로, max 보다 크면 max로
arr1 = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
arr2 = np.clip(arr1, 3, 7)
print(arr2)



#%% Embossing & Edge Detecion Kernel
im = imread('./images/tajmahal.jpg')/255 
emboss_kernel = np.array([[-2,-1,0],[-1,1,1],[0,1,2]])
edge_schar_kernel = np.array([[ -3-3j, 0-10j, +3 -3j], [-10+0j, 0+ 0j, +10+0j],[ -3+3j, 0+10j, +3 +3j]])

im_embossed = np.ones(im.shape)
im_edges = np.ones(im.shape)

for i in range(3):
    im_embossed[...,i] = np.clip(signal.convolve2d(im[...,i], emboss_kernel, mode='same', boundary="symm"),0,1)
for i in range(3):
    im_edges[...,i] = np.clip(np.real(signal.convolve2d(im[...,i], edge_schar_kernel, mode='same', boundary="symm")),0,1)

fig, axes = pylab.subplots(nrows=3, figsize=(20, 30))
axes[0].imshow(im)
axes[0].set_title('Original Image', size=20)
axes[1].imshow(im_embossed)
axes[1].set_title('Embossed Image', size=20)
axes[2].imshow(im_edges)
axes[2].set_title('Schar Edge Detection', size=20)
for ax in axes:
    ax.axis('off')
pylab.show()



#%% Scipy ndimgge.convolution Sharpening & Embossing
im = imread('./images/victoria_memorial.png').astype(np.float)
print(np.max(im))

sharpen_kernel = np.array([0, -1, 0, -1, 5, -1, 0, -1, 0]).reshape((3, 3, 1))
emboss_kernel = np.array(np.array([[-2,-1,0],[-1,1,1],[0,1,2]])).reshape((3, 3, 1))

im_sharp = ndimage.convolve(im, sharpen_kernel, mode='nearest')
im_sharp = np.clip(im_sharp, 0, 255).astype(np.uint8) 

im_emboss = ndimage.convolve(im, emboss_kernel, mode='nearest')
im_emboss = np.clip(im_emboss, 0, 255).astype(np.uint8)

pylab.figure(figsize=(10,15))
pylab.subplot(311), pylab.imshow(im.astype(np.uint8)), pylab.axis('off')
pylab.title('Original Image', size=25)
pylab.subplot(312), pylab.imshow(im_sharp), pylab.axis('off')
pylab.title('Sharpened Image', size=25)
pylab.subplot(313), pylab.imshow(im_emboss), pylab.axis('off')
pylab.title('Embossed Image', size=25)
pylab.tight_layout()
pylab.show()



#%% Template Matching with Correlation
face_image = misc.face(gray=True) - misc.face(gray=True).mean()

template_image = np.copy(face_image[300:365, 670:750])
template_image -= template_image.mean()

face_image = face_image + np.random.randn(*face_image.shape) * 50 
correlation = signal.correlate2d(face_image, template_image, boundary='symm', mode='same')
y, x = np.unravel_index(np.argmax(correlation), correlation.shape) # find the match

pylab.figure(figsize=(6, 15))
pylab.subplot(3,1,1), pylab.imshow(face_image, cmap='gray'), pylab.axis('off')
pylab.plot(x, y, 'ro')

pylab.title('Original Image', size=20)
pylab.subplot(3,1,2), pylab.imshow(template_image, cmap='gray'), pylab.axis('off')
pylab.title('Template', size=20)

pylab.subplot(3,1,3), pylab.imshow(correlation, cmap='afmhot'), pylab.axis('off')
pylab.title('OCross-correlation', size=20)
pylab.show()



#%% Drawing variation
fig, (ax_original, ax_template, ax_correlation) = pylab.subplots(3, 1, figsize=(6, 15))
ax_original.imshow(face_image, cmap='gray')
ax_original.set_title('Original', size=20)
ax_original.set_axis_off()

ax_template.imshow(template_image, cmap='gray')
ax_template.set_title('Template', size=20)
ax_template.set_axis_off()

ax_correlation.imshow(correlation, cmap='afmhot')
ax_correlation.set_title('Cross-correlation', size=20)
ax_correlation.set_axis_off()

ax_original.plot(x, y, 'ro')
fig.show()



#%% plot drawing
pylab.plot([1, 2, 3, 4], [1, 4, 9, 16], 'ro')
pylab.show()

pylab.plot(["Seoul","Paris","Seattle"], [30,25,55])
pylab.xlabel('City')
pylab.ylabel('Response')
pylab.title('Experiment Result')
pylab.show()

y = [5, 3, 7, 10, 9, 5, 3.5, 8]
x = range(len(y))
pylab.bar(x, y, width=0.7, color="blue")
pylab.show()
